﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Brant_Marvel_Santosa___AppDev_Take_Home_Week_08___0706022310005
{
    public partial class Form1 : Form
    {
        DataTable muncul = new DataTable();
        int harga = 0;
        int pajak = 0;
        bool kurang;
        int index;
        //t-shirt
        bool ada; bool ada2; bool ada3;
        //long pant
        bool ada4; bool ada5; bool ada6;
        //short pant
        bool ada7; bool ada8; bool ada9;
        //shoes
        bool ada10; bool ada11; bool ada12;
        //shirt
        bool ada14; bool ada15; bool ada16;
        //jewel
        bool ada17; bool ada18; bool ada19;
        //other
        bool ada13;
        public Form1()
        {
            InitializeComponent();
            if (muncul.Rows.Count == 0)
            {
                txt_sub.Text = "0,00";
                txt_pajak.Text = "0,00";
            }
        }

        private void txt_pajak_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            muncul.Columns.Add("Item Name");
            muncul.Columns.Add("Quantity");
            muncul.Columns.Add("Price");
            muncul.Columns.Add("Total");


            dgv_semua.DataSource = muncul;
        }


        private void txt_price_TextChanged(object sender, EventArgs e)
        {

        }

        private void txt_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_tshirt.Visible = true;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_shirt2.Visible = true;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_short.Visible = true;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_longpant.Visible = true;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_shoes.Visible = true;
        }

        private void jewelleriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_jewel.Visible = true;
        }

        private void othersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ganti_layar();
            pnl_other.Visible = true;
        }

        private void ganti_layar()
        {
            if (pnl_tshirt.Visible == true)
            {
                pnl_tshirt.Visible = false;
            }
            if (pnl_shirt2.Visible == true)
            {
                pnl_shirt2.Visible = false;
            }
            if (pnl_longpant.Visible == true)
            {
                pnl_longpant.Visible = false;
            }
            if (pnl_short.Visible == true)
            {
                pnl_short.Visible = false;
            }
            if (pnl_shoes.Visible == true)
            {
                pnl_shoes.Visible = false;
            }
            if (pnl_other.Visible == true)
            {
                pnl_other.Visible = false;
            }
            if (pnl_jewel.Visible == true)
            {
                pnl_jewel.Visible = false;
            }
        }

        private void subtotal(int harga, double pajak, bool kurang)
        {

            int hitung = 0;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                harga = harga + Convert.ToInt32(muncul.Rows[i][3].ToString());
            }
            if (kurang == false)
            {
                hitung = hitung + harga;
                pajak = harga + (hitung * 0.1);
            }
            else if (kurang == true)
            {
                hitung = hitung - harga;
                harga = hitung;
                pajak = pajak - (harga + (hitung * 0.1));
                kurang = false;
            }


            txt_sub.Text = harga.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            txt_pajak.Text = pajak.ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }





        private void btn_shirt1_Click(object sender, EventArgs e)
        {

        }

        private void pb_tshirt1_Click(object sender, EventArgs e)
        {

        }

        private void btn_addtshirt_Click(object sender, EventArgs e)
        {
            ada = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Seringal")
                {
                    ada = true;
                }
            }

            if (ada == false)
            {
                muncul.Rows.Add("T-Shirt Seringal", "1", "400000", "400000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Seringal")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_addtshirt2_Click(object sender, EventArgs e)
        {
            ada2 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Black Oversized")
                {
                    ada2 = true;
                }
            }

            if (ada2 == false)
            {
                muncul.Rows.Add("T-Shirt Black Oversized", "1", "200000", "200000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada2 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Black Oversized")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_addtshirt3_Click(object sender, EventArgs e)
        {
            ada3 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "T-Shirt Nirvana Grey")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada3 = true;
                }
            }

            if (ada3 == false)
            {
                muncul.Rows.Add("T-Shirt Nirvana Grey", "1", "250000", "250000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada3 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "T-Shirt Nirvana Grey")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void lbl_tshirt_harga2_Click(object sender, EventArgs e)
        {

        }

        private void pb_longpant3_Click(object sender, EventArgs e)
        {

        }

        private void btn_longpant1_Click(object sender, EventArgs e)
        {
            ada4 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Loose Long Pants")
                {
                    ada4 = true;
                }
            }

            if (ada4 == false)
            {
                muncul.Rows.Add("Loose Long Pants", "1", "150000", "150000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada4 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Loose Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);

                    }
                }
            }
        }

        private void btn_longpant2_Click(object sender, EventArgs e)
        {
            ada5 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Cargo Long Pants")
                {
                    ada5 = true;
                }
            }

            if (ada5 == false)
            {
                muncul.Rows.Add("Cargo Long Pants", "1", "200000", "200000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada5 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Cargo Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);

                    }
                }
            }
        }

        private void btn_longpant3_Click(object sender, EventArgs e)
        {
            ada6 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Black Slim Fit Long Pants")
                {
                    ada6 = true;
                }
            }

            if (ada6 == false)
            {
                muncul.Rows.Add("Black Slim Fit Long Pants", "1", "300000", "300000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada6 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Black Slim Fit Long Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);

                    }
                }
            }
        }

        private void btn_short1_Click(object sender, EventArgs e)
        {
            ada7 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Loose Black Short Pants")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada7 = true;
                }
            }

            if (ada7 == false)
            {
                muncul.Rows.Add("Loose Black Short Pants", "1", "150000", "150000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada7 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Loose Black Short Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_short2_Click(object sender, EventArgs e)
        {
            ada8 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Slim Fit Short Pants")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada8 = true;
                }
            }

            if (ada8 == false)
            {
                muncul.Rows.Add("Slim Fit Short Pants", "1", "250000", "250000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada8 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Slim Fit Short Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_short3_Click(object sender, EventArgs e)
        {
            ada9 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Naggi Short Pants")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada9 = true;
                }
            }

            if (ada9 == false)
            {
                muncul.Rows.Add("Naggi Short Pants", "1", "200000", "200000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada9 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Naggi Short Pants")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes1_Click(object sender, EventArgs e)
        {
            ada10 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Adidas Ultraboost")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada10 = true;
                }
            }

            if (ada10 == false)
            {
                muncul.Rows.Add("Adidas Ultraboost", "1", "3000000", "3000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada10 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Adidas Ultraboost")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes2_Click(object sender, EventArgs e)
        {
            ada11 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Nike Jordan Blue")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada11 = true;
                }
            }

            if (ada11 == false)
            {
                muncul.Rows.Add("Nike Jordan Blue", "1", "5000000", "5000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada11 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Nike Jordan Blue")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shoes3_Click(object sender, EventArgs e)
        {
            ada12 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "MLB Shoes")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada12 = true;
                }
            }

            if (ada12 == false)
            {
                muncul.Rows.Add("MLB Shoes", "1", "10000000", "10000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada12 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "MLB Shoes")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void label30_Click(object sender, EventArgs e)
        {

        }

        private void label28_Click(object sender, EventArgs e)
        {

        }

        private void pnl_jewel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btn_jewel1_Click(object sender, EventArgs e)
        {
            ada17 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Maharashtrian Bridal")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada17 = true;
                }
            }

            if (ada17 == false)
            {
                muncul.Rows.Add("Maharashtrian Bridal", "1", "20000000", "20000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada17 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Maharashtrian Bridal")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_jewel2_Click(object sender, EventArgs e)
        {
            ada18 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Katrina Kundan")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada18 = true;
                }
            }

            if (ada18 == false)
            {
                muncul.Rows.Add("Katrina Kundan", "1", "15000000", "15000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada18 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Katrina Kundan")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_jewel3_Click(object sender, EventArgs e)
        {
            ada19 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "White Gold")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada19 = true;
                }
            }

            if (ada19 == false)
            {
                muncul.Rows.Add("White Gold", "1", "45000000", "45000000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada19 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "White Gold")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shirt4_Click(object sender, EventArgs e)
        {
            ada14 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Kemeja Light Blue")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada14 = true;
                }
            }

            if (ada14 == false)
            {
                muncul.Rows.Add("Kemeja Light Blue", "1", "300000", "300000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada14 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Kemeja Light Blue")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shirt5_Click(object sender, EventArgs e)
        {
            ada15 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Black Oversized Shirt")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada15 = true;
                }
            }

            if (ada15 == false)
            {
                muncul.Rows.Add("Black Oversized Shirt", "1", "150000", "150000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada15 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Black Oversized Shirt")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_shirt6_Click(object sender, EventArgs e)
        {
            ada16 = false;
            for (int i = 0; i < muncul.Rows.Count; i++)
            {
                if (muncul.Rows[i][0].ToString() == "Kemeja Kotak-Kotak")
                {
                    int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                    ada16 = true;
                }
            }

            if (ada16 == false)
            {
                muncul.Rows.Add("Kemeja Kotak-Kotak", "1", "350000", "350000");
                subtotal(harga, pajak, kurang);
            }
            else if (ada16 == true)
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == "Kemeja Kotak-Kotak")
                    {
                        int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                        int many = quan + 1;
                        muncul.Rows[i][1] = many.ToString();
                        muncul.Rows[i][3] = (biaya * many).ToString();
                        subtotal(harga, pajak, kurang);
                    }
                }
            }
        }

        private void btn_addother_Click(object sender, EventArgs e)
        {
            ada12 = false;

            if (txt_itemname.Text == "" && txt_price.Text == "")
            {
                MessageBox.Show("masukan nama barang dan harga", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                for (int i = 0; i < muncul.Rows.Count; i++)
                {
                    if (muncul.Rows[i][0].ToString() == txt_itemname.Text)
                    {
                        int banyak = Convert.ToInt32(muncul.Rows[i][1].ToString());
                        ada12 = true;
                    }
                }

                if (ada12 == false)
                {
                    muncul.Rows.Add(txt_itemname.Text, "1", txt_price.Text, txt_price.Text);
                    subtotal(harga, pajak, kurang);
                }
                else if (ada12 == true)
                {
                    for (int i = 0; i < muncul.Rows.Count; i++)
                    {
                        if (muncul.Rows[i][0].ToString() == txt_itemname.Text)
                        {
                            int quan = Convert.ToInt32(muncul.Rows[i][1].ToString());
                            int biaya = Convert.ToInt32(muncul.Rows[i][2].ToString());
                            int many = quan + 1;
                            muncul.Rows[i][1] = many.ToString();
                            muncul.Rows[i][3] = (biaya * many).ToString();
                            subtotal(harga, pajak, kurang);
                        }
                    }
                }
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            kurang = true;
            foreach (DataGridViewRow hapus in dgv_semua.SelectedRows)
            {

                dgv_semua.Rows.RemoveAt(hapus.Index);
                subtotal(harga, pajak, kurang);
            }
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {

        }
    }
}

